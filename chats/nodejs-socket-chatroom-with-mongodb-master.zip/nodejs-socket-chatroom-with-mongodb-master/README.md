#Simple  Chat
===================

i use NodeJS-MongoDB-express-ejs in this App

for test this app you should

		--first download and Install Nodejs
		--then download and Install MongoDB 
		--run  'npm install' 
		--then enter 'npm run start'

in port :3000 its serve now ,,,

===================
